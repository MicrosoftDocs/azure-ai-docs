After analyzing this specification document, engage me in a conversation to gather information for creating technical documentation. Instead of listing all questions at once, ask me one question at a time and use my responses to guide our discussion.

Begin by:
1. Identifying what type of document would be most appropriate (conceptual, how-to, quickstart/tutorial, or reference)
2. Explaining your initial understanding of the topic
3. Asking your first targeted question about an aspect that needs clarification

Then, proceed with an interactive conversation where you:
- Ask one focused question at a time based on my previous answers
- Acknowledge my responses and build upon them
- Adapt your questioning based on the information I provide
- Occasionally summarize what you've learned so far
- Identify when you have enough information on one aspect before moving to the next
- Inform me when you believe we've covered all necessary information

Areas to cover through our conversation:
- User prerequisites and environment setup
- Core concepts and technical context
- Implementation steps and code requirements
- Expected outcomes and verification
- Common issues and their solutions
- Related features or integration points

After gathering sufficient information, draft the document according to the appropriate template and present it for my review.