As a technical editor, analyze these markdown documentation files collectively and recommend how to consolidate them to reduce both word count and article count while maintaining clarity and usefulness.

ANALYSIS INSTRUCTIONS:

1. CONTENT INVENTORY: For each document, create a one-sentence summary and list its main topics.

2. OVERLAP IDENTIFICATION: Find duplicated content across documents including:
   - Repeated concepts or explanations
   - Similar code examples
   - Redundant prerequisites or setup instructions
   - Overlapping troubleshooting sections

3. CONSOLIDATION OPPORTUNITIES: Identify how articles could be combined by:
   - Merging conceptually related topics
   - Creating unified how-to guides from fragmented instructions
   - Consolidating similar quickstarts into single comprehensive tutorials
   - Combining repetitive setup/prerequisite sections

4. CONTENT PRESERVATION: Highlight critical information that must be retained despite consolidation.

5. REORGANIZATION PROPOSAL: Present a new document structure showing:
   - Which documents should be combined
   - Which should remain separate
   - Which can be eliminated entirely
   - Which content should be moved to different documents

FORMAT YOUR RESPONSE AS:

## Current State Analysis
- Total documents: [number]
- Total word count: [count]
- Redundancy percentage: [estimate]

## Consolidation Plan
For each proposed new document:
- **New Title**: [descriptive title]
- **Combined from**: [list of original documents]
- **Content outline**: [major sections]
- **Estimated word reduction**: [percentage]
- **Reasoning**: [why this combination makes sense]

## Content Migration Map
Show specifically what content moves where using this format:

Original Document A:

Section 1 → New Document X
Section 2 → [DELETE - redundant with Document B]
Section 3 → New Document Y


## Expected Results
- New document count: [number]
- Total word reduction: [percentage]
- Improved user experience: [brief description]

## Risk Assessment
- Content that might be lost: [list]
- Potential user confusion points: [list]
- Recommended mitigations: [list]